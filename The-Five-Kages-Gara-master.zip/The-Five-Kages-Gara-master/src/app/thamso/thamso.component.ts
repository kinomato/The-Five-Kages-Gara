import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-thamso',
  templateUrl: './thamso.component.html',
  styleUrls: ['./thamso.component.css']
})
export class ThamsoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
