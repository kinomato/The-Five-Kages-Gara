import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { auth } from 'firebase/app';
import { AngularFireAuth } from '@angular/fire/auth';
import { AngularFirestore, AngularFirestoreDocument } from '@angular/fire/firestore';
import { Observable, observable, of } from 'rxjs';
import { switchMap } from 'rxjs/operators';
import { User } from 'src/app/models/user.model';
import { FirebaseAuth } from '@angular/fire';
import { EmailValidator } from '@angular/forms';

@Injectable({
  providedIn: 'root'
})
export class DangnhapService {
  user: Observable<User>;
  authState: FirebaseAuth = null
  constructor(
    private afAuth: AngularFireAuth,
    private afs: AngularFirestore,
    private router: Router
  ){
    /*afAuth.auth.subscribe((auth) => {
      this.authState = auth;
    });*/
    this.user = this.afAuth.authState.pipe(
      switchMap(user => {
        if(user){
          return this.afs.doc<User>('user/{user.id}').valueChanges();
        }else {
          return of(null);
        }
      })
    );
  }

  async googleSingin(){
    const provider = new auth.GoogleAuthProvider();
    const credential = await this.afAuth.auth.signInWithPopup(provider);
    return this.updateUserData(credential.user)
  }

  async signOut(){
    await this.afAuth.auth.signOut();
    return this.router.navigate(['/']);
  }

  private updateUserData(user){
    const userRef : AngularFirestoreDocument<User> = this.afs.doc('user/{uid}');
    const data = {
      uid: user.id,
      email: user.email
    };
    return userRef.set(data,{merge:true});
  }
  
}// end class DangnhapService

