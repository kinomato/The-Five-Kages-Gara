import { TestBed } from '@angular/core/testing';

import { DangnhapService } from './dangnhap.service';

describe('DangnhapService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: DangnhapService = TestBed.get(DangnhapService);
    expect(service).toBeTruthy();
  });
});
