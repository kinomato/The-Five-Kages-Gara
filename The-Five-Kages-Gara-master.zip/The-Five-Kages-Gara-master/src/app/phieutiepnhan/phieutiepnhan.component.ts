import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-phieutiepnhan',
  templateUrl: './phieutiepnhan.component.html',
  styleUrls: ['./phieutiepnhan.component.css']
})
export class PhieutiepnhanComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
