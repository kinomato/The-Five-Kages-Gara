import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-phieusuachua',
  templateUrl: './phieusuachua.component.html',
  styleUrls: ['./phieusuachua.component.css']
})
export class PhieusuachuaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
