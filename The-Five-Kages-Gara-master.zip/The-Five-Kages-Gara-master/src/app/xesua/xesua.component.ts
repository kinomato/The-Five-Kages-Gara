import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-xesua',
  templateUrl: './xesua.component.html',
  styleUrls: ['./xesua.component.css']
})
export class XesuaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
