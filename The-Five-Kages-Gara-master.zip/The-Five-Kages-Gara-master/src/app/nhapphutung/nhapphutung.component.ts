import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nhapphutung',
  templateUrl: './nhapphutung.component.html',
  styleUrls: ['./nhapphutung.component.css']
})
export class NhapphutungComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
