import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hieuxe',
  templateUrl: './hieuxe.component.html',
  styleUrls: ['./hieuxe.component.css']
})
export class HieuxeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
