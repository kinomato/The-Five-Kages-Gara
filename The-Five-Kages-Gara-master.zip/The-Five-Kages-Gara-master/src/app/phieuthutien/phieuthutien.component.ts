import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-phieuthutien',
  templateUrl: './phieuthutien.component.html',
  styleUrls: ['./phieuthutien.component.css']
})
export class PhieuthutienComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
