import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tiencong',
  templateUrl: './tiencong.component.html',
  styleUrls: ['./tiencong.component.css']
})
export class TiencongComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
