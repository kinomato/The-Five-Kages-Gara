export interface CustomResObject {
    createTime: string;
    fields: any;
    updateTime: string;
    name: string;
}
