export interface CustomResObjectList {
    documents: [];
}
