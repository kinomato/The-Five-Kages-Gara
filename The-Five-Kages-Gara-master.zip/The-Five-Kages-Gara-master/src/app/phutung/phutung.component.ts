import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-phutung',
  templateUrl: './phutung.component.html',
  styleUrls: ['./phutung.component.css']
})
export class PhutungComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
