export class Employee {
    constructor(
        public id: string,
        public fullname: string,
        public empCode: string,
        public position: string,
        public mobile: string
    ) {

    }
}
