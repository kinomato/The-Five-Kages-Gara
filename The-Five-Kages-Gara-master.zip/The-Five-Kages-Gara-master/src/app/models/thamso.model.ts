export class Thamso {
    constructor(
        public idthamso: string,
        public tenthamso: string,
        public giatri: string
    ) {}
}
