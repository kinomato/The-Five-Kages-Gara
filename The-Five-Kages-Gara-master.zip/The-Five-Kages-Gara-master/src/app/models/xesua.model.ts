export class Xesua {
    constructor(
        public idxesua: string,
        public idhieuxe: string,
        public idkhachhang: string,
        public bienso: string
    ) {}
}
