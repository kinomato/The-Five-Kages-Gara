export class Tiencong {
    constructor(
        public idtiencong: string,
        public tenloaitiencong: string,
        public muctiencong: string
    ) {}
}
