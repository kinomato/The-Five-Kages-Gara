export class Phutung {
    constructor(
        public idphutung: string,
        public tenphutung: string,
        public giaphutung: string,
        public soluongconlai: number
    ) {}
}
