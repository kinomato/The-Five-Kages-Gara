export class Khachhang {
    constructor(
        public idkhachhang: string,
        public tenkhachhang: string,
        public diachi: string,
        public dienthoai: string
    ) {}
}
