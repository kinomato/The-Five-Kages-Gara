export class Hieuxe {
    constructor(
        public idhieuxe: string,
        public hieuxe: string
        ) {}
}
