export const environment = {
  production: true,
  firebase: {
    apiKey: 'AIzaSyA7HycuLcoJcDTz3Wpx_5-eSmEOpbEoysY',
    authDomain: 'cloud-firestore-test-f68a5.firebaseapp.com',
    databaseURL: 'https://cloud-firestore-test-f68a5.firebaseio.com',
    projectId: 'cloud-firestore-test-f68a5',
    storageBucket: 'cloud-firestore-test-f68a5.appspot.com',
    messagingSenderId: '563099177609'
  }
};
